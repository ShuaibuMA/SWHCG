"""Standard unconstrained test problems (Andrei collection / CUTEst analogues).

Each problem: name, x0(n) -> ndarray, f(x) -> float, g(x) -> ndarray.
All formulas are the standard ones from N. Andrei, "An unconstrained
optimization test functions collection" (Adv. Model. Optim. 10, 2008)
and the CUTEst library.
"""
import numpy as np


class P:
    def __init__(self, name, f, g, x0):
        self.name, self.f, self.g, self.x0 = name, f, g, x0


PROBLEMS = []


def register(name, x0):
    def deco(builder):
        f, g = builder()
        PROBLEMS.append(P(name, f, g, x0))
        return builder
    return deco


# ---------------------------------------------------------------- 1
@register("Extended Rosenbrock", lambda n: np.tile([-1.2, 1.0], n // 2))
def _():
    def f(x):
        xo, xe = x[0::2], x[1::2]
        return np.sum(100.0 * (xe - xo ** 2) ** 2 + (1.0 - xo) ** 2)

    def g(x):
        xo, xe = x[0::2], x[1::2]
        gr = np.zeros_like(x)
        gr[0::2] = -400.0 * xo * (xe - xo ** 2) - 2.0 * (1.0 - xo)
        gr[1::2] = 200.0 * (xe - xo ** 2)
        return gr
    return f, g


# ---------------------------------------------------------------- 2
@register("Extended White & Holst", lambda n: np.tile([-1.2, 1.0], n // 2))
def _():
    c = 100.0

    def f(x):
        xo, xe = x[0::2], x[1::2]
        return np.sum(c * (xe - xo ** 3) ** 2 + (1.0 - xo) ** 2)

    def g(x):
        xo, xe = x[0::2], x[1::2]
        gr = np.zeros_like(x)
        gr[0::2] = -6.0 * c * xo ** 2 * (xe - xo ** 3) - 2.0 * (1.0 - xo)
        gr[1::2] = 2.0 * c * (xe - xo ** 3)
        return gr
    return f, g


# ---------------------------------------------------------------- 3
@register("Extended Beale", lambda n: np.tile([1.0, 0.8], n // 2))
def _():
    def parts(x):
        u, v = x[0::2], x[1::2]
        a = 1.5 - u * (1 - v)
        b = 2.25 - u * (1 - v ** 2)
        c = 2.625 - u * (1 - v ** 3)
        return u, v, a, b, c

    def f(x):
        _, _, a, b, c = parts(x)
        return np.sum(a ** 2 + b ** 2 + c ** 2)

    def g(x):
        u, v, a, b, c = parts(x)
        gr = np.zeros_like(x)
        gr[0::2] = 2 * a * (-(1 - v)) + 2 * b * (-(1 - v ** 2)) + 2 * c * (-(1 - v ** 3))
        gr[1::2] = 2 * a * u + 2 * b * (2 * u * v) + 2 * c * (3 * u * v ** 2)
        return gr
    return f, g


# ---------------------------------------------------------------- 4
@register("Extended Himmelblau", lambda n: np.tile([1.0, 1.0], n // 2))
def _():
    def f(x):
        u, v = x[0::2], x[1::2]
        return np.sum((u ** 2 + v - 11.0) ** 2 + (u + v ** 2 - 7.0) ** 2)

    def g(x):
        u, v = x[0::2], x[1::2]
        a = u ** 2 + v - 11.0
        b = u + v ** 2 - 7.0
        gr = np.zeros_like(x)
        gr[0::2] = 4 * a * u + 2 * b
        gr[1::2] = 2 * a + 4 * b * v
        return gr
    return f, g


# ---------------------------------------------------------------- 5
@register("ARWHEAD", lambda n: np.ones(n))
def _():
    def f(x):
        xi, xn = x[:-1], x[-1]
        return np.sum((xi ** 2 + xn ** 2) ** 2 - 4.0 * xi + 3.0)

    def g(x):
        xi, xn = x[:-1], x[-1]
        t = xi ** 2 + xn ** 2
        gr = np.zeros_like(x)
        gr[:-1] = 4.0 * t * xi - 4.0
        gr[-1] = np.sum(4.0 * t * xn)
        return gr
    return f, g


# ---------------------------------------------------------------- 6
@register("NONDIA", lambda n: -np.ones(n))
def _():
    def f(x):
        return (x[0] - 1.0) ** 2 + np.sum(100.0 * (x[0] - x[:-1] ** 2) ** 2)

    def g(x):
        r = x[0] - x[:-1] ** 2
        gr = np.zeros_like(x)
        gr[:-1] = -400.0 * r * x[:-1]
        gr[0] += 2.0 * (x[0] - 1.0) + np.sum(200.0 * r)
        return gr
    return f, g


# ---------------------------------------------------------------- 7
@register("DQDRTIC", lambda n: 3.0 * np.ones(n))
def _():
    c, d = 100.0, 100.0

    def f(x):
        return np.sum(x[:-2] ** 2 + c * x[1:-1] ** 2 + d * x[2:] ** 2)

    def g(x):
        gr = np.zeros_like(x)
        gr[:-2] += 2.0 * x[:-2]
        gr[1:-1] += 2.0 * c * x[1:-1]
        gr[2:] += 2.0 * d * x[2:]
        return gr
    return f, g


# ---------------------------------------------------------------- 8
@register("LIARWHD", lambda n: 4.0 * np.ones(n))
def _():
    def f(x):
        return np.sum(4.0 * (x ** 2 - x[0]) ** 2 + (x - 1.0) ** 2)

    def g(x):
        r = x ** 2 - x[0]
        gr = 16.0 * r * x + 2.0 * (x - 1.0)
        gr[0] += np.sum(-8.0 * r)
        return gr
    return f, g


# ---------------------------------------------------------------- 9
@register("POWER", lambda n: np.ones(n))
def _():
    def f(x):
        i = np.arange(1, x.size + 1)
        return np.sum((i * x) ** 2)

    def g(x):
        i = np.arange(1, x.size + 1)
        return 2.0 * i ** 2 * x
    return f, g


# ---------------------------------------------------------------- 10
@register("QUARTC", lambda n: 2.0 * np.ones(n))
def _():
    def f(x):
        i = np.arange(1, x.size + 1)
        return np.sum((x - i) ** 4)

    def g(x):
        i = np.arange(1, x.size + 1)
        return 4.0 * (x - i) ** 3
    return f, g


# ---------------------------------------------------------------- 11
@register("TRIDIA", lambda n: np.ones(n))
def _():
    def f(x):
        i = np.arange(2, x.size + 1)
        return (x[0] - 1.0) ** 2 + np.sum(i * (2.0 * x[1:] - x[:-1]) ** 2)

    def g(x):
        i = np.arange(2, x.size + 1)
        r = 2.0 * x[1:] - x[:-1]
        gr = np.zeros_like(x)
        gr[1:] += 4.0 * i * r
        gr[:-1] += -2.0 * i * r
        gr[0] += 2.0 * (x[0] - 1.0)
        return gr
    return f, g


# ---------------------------------------------------------------- 12
@register("Generalized Tridiagonal 1", lambda n: 2.0 * np.ones(n))
def _():
    def f(x):
        a = x[:-1] + x[1:] - 3.0
        b = x[:-1] - x[1:] + 1.0
        return np.sum(a ** 2 + b ** 4)

    def g(x):
        a = x[:-1] + x[1:] - 3.0
        b = x[:-1] - x[1:] + 1.0
        gr = np.zeros_like(x)
        gr[:-1] += 2.0 * a + 4.0 * b ** 3
        gr[1:] += 2.0 * a - 4.0 * b ** 3
        return gr
    return f, g


# ---------------------------------------------------------------- 13
@register("BDQRTIC", lambda n: np.ones(n))
def _():
    def f(x):
        n = x.size
        xi = x[: n - 4]
        t = xi ** 2 + 2 * x[1:n-3] ** 2 + 3 * x[2:n-2] ** 2 + 4 * x[3:n-1] ** 2 + 5 * x[-1] ** 2
        return np.sum((-4.0 * xi + 3.0) ** 2 + t ** 2)

    def g(x):
        n = x.size
        xi = x[: n - 4]
        t = xi ** 2 + 2 * x[1:n-3] ** 2 + 3 * x[2:n-2] ** 2 + 4 * x[3:n-1] ** 2 + 5 * x[-1] ** 2
        gr = np.zeros_like(x)
        gr[: n - 4] += -8.0 * (-4.0 * xi + 3.0) + 4.0 * t * xi
        gr[1:n-3] += 8.0 * t * x[1:n-3]
        gr[2:n-2] += 12.0 * t * x[2:n-2]
        gr[3:n-1] += 16.0 * t * x[3:n-1]
        gr[-1] += np.sum(20.0 * t) * x[-1]
        return gr
    return f, g


# ---------------------------------------------------------------- 14
@register("EDENSCH", lambda n: np.zeros(n))
def _():
    def f(x):
        a = x[:-1] - 2.0
        b = x[:-1] * x[1:] - 2.0 * x[1:]
        c = x[1:] + 1.0
        return 16.0 + np.sum(a ** 4 + b ** 2 + c ** 2)

    def g(x):
        a = x[:-1] - 2.0
        b = x[:-1] * x[1:] - 2.0 * x[1:]
        c = x[1:] + 1.0
        gr = np.zeros_like(x)
        gr[:-1] += 4.0 * a ** 3 + 2.0 * b * x[1:]
        gr[1:] += 2.0 * b * (x[:-1] - 2.0) + 2.0 * c
        return gr
    return f, g


# ---------------------------------------------------------------- 15
@register("ENGVAL1", lambda n: 2.0 * np.ones(n))
def _():
    def f(x):
        t = x[:-1] ** 2 + x[1:] ** 2
        return np.sum(t ** 2 - 4.0 * x[:-1] + 3.0)

    def g(x):
        t = x[:-1] ** 2 + x[1:] ** 2
        gr = np.zeros_like(x)
        gr[:-1] += 4.0 * t * x[:-1] - 4.0
        gr[1:] += 4.0 * t * x[1:]
        return gr
    return f, g


# ---------------------------------------------------------------- 16
@register("COSINE", lambda n: np.ones(n))
def _():
    def f(x):
        return np.sum(np.cos(-0.5 * x[1:] + x[:-1] ** 2))

    def g(x):
        s = np.sin(-0.5 * x[1:] + x[:-1] ** 2)
        gr = np.zeros_like(x)
        gr[:-1] += -s * 2.0 * x[:-1]
        gr[1:] += 0.5 * s
        return gr
    return f, g


# ---------------------------------------------------------------- 17
@register("Extended Penalty", lambda n: np.arange(1.0, n + 1.0))
def _():
    def f(x):
        return np.sum((x[:-1] - 1.0) ** 2) + (np.sum(x ** 2) - 0.25) ** 2

    def g(x):
        q = np.sum(x ** 2) - 0.25
        gr = 4.0 * q * x
        gr[:-1] += 2.0 * (x[:-1] - 1.0)
        return gr
    return f, g


# ---------------------------------------------------------------- 18
@register("Hager", lambda n: np.ones(n))
def _():
    def f(x):
        i = np.arange(1, x.size + 1)
        return np.sum(np.exp(x) - np.sqrt(i) * x)

    def g(x):
        i = np.arange(1, x.size + 1)
        return np.exp(x) - np.sqrt(i)
    return f, g


# ---------------------------------------------------------------- 19
@register("Raydan 2", lambda n: np.ones(n))
def _():
    def f(x):
        return np.sum(np.exp(x) - x)

    def g(x):
        return np.exp(x) - 1.0
    return f, g


# ---------------------------------------------------------------- 20
@register("FLETCHCR", lambda n: np.zeros(n))
def _():
    def f(x):
        r = x[1:] - x[:-1] + 1.0 - x[:-1] ** 2
        return np.sum(100.0 * r ** 2)

    def g(x):
        r = x[1:] - x[:-1] + 1.0 - x[:-1] ** 2
        gr = np.zeros_like(x)
        gr[1:] += 200.0 * r
        gr[:-1] += 200.0 * r * (-1.0 - 2.0 * x[:-1])
        return gr
    return f, g


# ---------------------------------------------------------------- 21
@register("Extended Powell Singular", lambda n: np.tile([3.0, -1.0, 0.0, 1.0], n // 4))
def _():
    def f(x):
        x1, x2, x3, x4 = x[0::4], x[1::4], x[2::4], x[3::4]
        return np.sum((x1 + 10 * x2) ** 2 + 5 * (x3 - x4) ** 2
                      + (x2 - 2 * x3) ** 4 + 10 * (x1 - x4) ** 4)

    def g(x):
        x1, x2, x3, x4 = x[0::4], x[1::4], x[2::4], x[3::4]
        a = x1 + 10 * x2
        b = x3 - x4
        c = x2 - 2 * x3
        d = x1 - x4
        gr = np.zeros_like(x)
        gr[0::4] = 2 * a + 40 * d ** 3
        gr[1::4] = 20 * a + 4 * c ** 3
        gr[2::4] = 10 * b - 8 * c ** 3
        gr[3::4] = -10 * b - 40 * d ** 3
        return gr
    return f, g


# ---------------------------------------------------------------- 22
@register("WOODS", lambda n: np.tile([-3.0, -1.0, -3.0, -1.0], n // 4))
def _():
    def f(x):
        x1, x2, x3, x4 = x[0::4], x[1::4], x[2::4], x[3::4]
        return np.sum(100 * (x2 - x1 ** 2) ** 2 + (1 - x1) ** 2
                      + 90 * (x4 - x3 ** 2) ** 2 + (1 - x3) ** 2
                      + 10 * (x2 + x4 - 2) ** 2 + 0.1 * (x2 - x4) ** 2)

    def g(x):
        x1, x2, x3, x4 = x[0::4], x[1::4], x[2::4], x[3::4]
        gr = np.zeros_like(x)
        gr[0::4] = -400 * x1 * (x2 - x1 ** 2) - 2 * (1 - x1)
        gr[1::4] = 200 * (x2 - x1 ** 2) + 20 * (x2 + x4 - 2) + 0.2 * (x2 - x4)
        gr[2::4] = -360 * x3 * (x4 - x3 ** 2) - 2 * (1 - x3)
        gr[3::4] = 180 * (x4 - x3 ** 2) + 20 * (x2 + x4 - 2) - 0.2 * (x2 - x4)
        return gr
    return f, g


# ---------------------------------------------------------------- 23
@register("Broyden Tridiagonal", lambda n: -np.ones(n))
def _():
    def resid(x):
        xm = np.concatenate(([0.0], x[:-1]))
        xp = np.concatenate((x[1:], [0.0]))
        return (3.0 - 2.0 * x) * x - xm - 2.0 * xp + 1.0

    def f(x):
        return np.sum(resid(x) ** 2)

    def g(x):
        r = resid(x)
        gr = 2.0 * r * (3.0 - 4.0 * x)
        gr[:-1] += -2.0 * r[1:]
        gr[1:] += -4.0 * r[:-1]
        return gr
    return f, g


# ---------------------------------------------------------------- 24
@register("Extended Freudenstein & Roth", lambda n: np.tile([0.5, -2.0], n // 2))
def _():
    def parts(x):
        u, v = x[0::2], x[1::2]
        a = -13.0 + u + ((5.0 - v) * v - 2.0) * v
        b = -29.0 + u + ((v + 1.0) * v - 14.0) * v
        return u, v, a, b

    def f(x):
        _, _, a, b = parts(x)
        return np.sum(a ** 2 + b ** 2)

    def g(x):
        u, v, a, b = parts(x)
        da = 10.0 * v - 3.0 * v ** 2 - 2.0
        db = 3.0 * v ** 2 + 2.0 * v - 14.0
        gr = np.zeros_like(x)
        gr[0::2] = 2.0 * a + 2.0 * b
        gr[1::2] = 2.0 * a * da + 2.0 * b * db
        return gr
    return f, g


# ---------------------------------------------------------------- 25
@register("Generalized Rosenbrock", lambda n: np.tile([-1.2, 1.0], n // 2))
def _():
    def f(x):
        return np.sum(100.0 * (x[1:] - x[:-1] ** 2) ** 2 + (1.0 - x[:-1]) ** 2)

    def g(x):
        r = x[1:] - x[:-1] ** 2
        gr = np.zeros_like(x)
        gr[:-1] += -400.0 * r * x[:-1] - 2.0 * (1.0 - x[:-1])
        gr[1:] += 200.0 * r
        return gr
    return f, g


# ---------------------------------------------------------------- 26
@register("Diagonal 4", lambda n: np.ones(n))
def _():
    c = 100.0

    def f(x):
        u, v = x[0::2], x[1::2]
        return 0.5 * np.sum(u ** 2 + c * v ** 2)

    def g(x):
        gr = np.zeros_like(x)
        gr[0::2] = x[0::2]
        gr[1::2] = c * x[1::2]
        return gr
    return f, g


# ---------------------------------------------------------------- 27
@register("Perturbed Quadratic", lambda n: 0.5 * np.ones(n))
def _():
    def f(x):
        i = np.arange(1, x.size + 1)
        return np.sum(i * x ** 2) + (np.sum(x)) ** 2 / 100.0

    def g(x):
        i = np.arange(1, x.size + 1)
        return 2.0 * i * x + 2.0 * np.sum(x) / 100.0
    return f, g


# ---------------------------------------------------------------- 28
@register("Almost Perturbed Quadratic", lambda n: 0.5 * np.ones(n))
def _():
    def f(x):
        i = np.arange(1, x.size + 1)
        return np.sum(i * x ** 2) + (x[0] + x[-1]) ** 2 / 100.0

    def g(x):
        i = np.arange(1, x.size + 1)
        gr = 2.0 * i * x
        t = 2.0 * (x[0] + x[-1]) / 100.0
        gr[0] += t
        gr[-1] += t
        return gr
    return f, g


# ---------------------------------------------------------------- 29
@register("QF1", lambda n: np.ones(n))
def _():
    def f(x):
        i = np.arange(1, x.size + 1)
        return 0.5 * np.sum(i * x ** 2) - x[-1]

    def g(x):
        i = np.arange(1, x.size + 1)
        gr = i * x
        gr[-1] -= 1.0
        return gr
    return f, g


# ---------------------------------------------------------------- 30
@register("Extended DENSCHNB", lambda n: np.ones(n))
def _():
    def f(x):
        u, v = x[0::2], x[1::2]
        return np.sum((u - 2.0) ** 2 + (u - 2.0) ** 2 * v ** 2 + (v + 1.0) ** 2)

    def g(x):
        u, v = x[0::2], x[1::2]
        gr = np.zeros_like(x)
        gr[0::2] = 2.0 * (u - 2.0) * (1.0 + v ** 2)
        gr[1::2] = 2.0 * (u - 2.0) ** 2 * v + 2.0 * (v + 1.0)
        return gr
    return f, g


# ---------------------------------------------------------------- 31
@register("Extended DENSCHNF", lambda n: np.tile([2.0, 0.0], n // 2))
def _():
    def parts(x):
        u, v = x[0::2], x[1::2]
        a = 2.0 * (u + v) ** 2 + (u - v) ** 2 - 8.0
        b = 5.0 * u ** 2 + (v - 3.0) ** 2 - 9.0
        return u, v, a, b

    def f(x):
        _, _, a, b = parts(x)
        return np.sum(a ** 2 + b ** 2)

    def g(x):
        u, v, a, b = parts(x)
        gr = np.zeros_like(x)
        gr[0::2] = 2 * a * (4 * (u + v) + 2 * (u - v)) + 2 * b * 10 * u
        gr[1::2] = 2 * a * (4 * (u + v) - 2 * (u - v)) + 2 * b * 2 * (v - 3.0)
        return gr
    return f, g


# ---------------------------------------------------------------- 32
@register("DIXON3DQ", lambda n: -np.ones(n))
def _():
    def f(x):
        return (x[0] - 1.0) ** 2 + np.sum((x[:-1] - x[1:]) ** 2) + (x[-1] - 1.0) ** 2

    def g(x):
        d = x[:-1] - x[1:]
        gr = np.zeros_like(x)
        gr[:-1] += 2.0 * d
        gr[1:] += -2.0 * d
        gr[0] += 2.0 * (x[0] - 1.0)
        gr[-1] += 2.0 * (x[-1] - 1.0)
        return gr
    return f, g


# ---------------------------------------------------------------- 33
@register("NONSCOMP", lambda n: 3.0 * np.ones(n))
def _():
    def f(x):
        return (x[0] - 1.0) ** 2 + np.sum(4.0 * (x[1:] - x[:-1] ** 2) ** 2)

    def g(x):
        r = x[1:] - x[:-1] ** 2
        gr = np.zeros_like(x)
        gr[1:] += 8.0 * r
        gr[:-1] += -16.0 * r * x[:-1]
        gr[0] += 2.0 * (x[0] - 1.0)
        return gr
    return f, g


# ---------------------------------------------------------------- 34
@register("Generalized Quartic", lambda n: np.ones(n))
def _():
    def f(x):
        return np.sum(x[:-1] ** 2) + np.sum((x[1:] + x[:-1] ** 2) ** 2)

    def g(x):
        t = x[1:] + x[:-1] ** 2
        gr = np.zeros_like(x)
        gr[:-1] += 2.0 * x[:-1] + 4.0 * t * x[:-1]
        gr[1:] += 2.0 * t
        return gr
    return f, g


# ---------------------------------------------------------------- 35
@register("Extended Tridiagonal 1", lambda n: 2.0 * np.ones(n))
def _():
    def f(x):
        u, v = x[0::2], x[1::2]
        return np.sum((u + v - 3.0) ** 2 + (u - v + 1.0) ** 4)

    def g(x):
        u, v = x[0::2], x[1::2]
        a = u + v - 3.0
        b = (u - v + 1.0) ** 3
        gr = np.zeros_like(x)
        gr[0::2] = 2.0 * a + 4.0 * b
        gr[1::2] = 2.0 * a - 4.0 * b
        return gr
    return f, g


def check_gradients():
    """Finite-difference verification of every gradient."""
    rng = np.random.default_rng(0)
    ok = True
    for p in PROBLEMS:
        n = 8
        x = p.x0(n) + 0.05 * rng.standard_normal(n)
        gnum = np.zeros(n)
        h = 1e-6
        for j in range(n):
            e = np.zeros(n); e[j] = h
            gnum[j] = (p.f(x + e) - p.f(x - e)) / (2 * h)
        ga = p.g(x)
        err = np.max(np.abs(ga - gnum)) / (1.0 + np.max(np.abs(gnum)))
        status = "OK " if err < 1e-5 else "FAIL"
        if err >= 1e-5:
            ok = False
        print(f"{status} {p.name:35s} rel.err = {err:.2e}")
    return ok


if __name__ == "__main__":
    assert check_gradients()
