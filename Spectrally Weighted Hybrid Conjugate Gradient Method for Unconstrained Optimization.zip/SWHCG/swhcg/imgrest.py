"""Two-phase salt-and-pepper denoising (Chan-Ho-Nikolova / Cai-Chan-Nikolova edge-preserving model),
the standard image-restoration test for nonlinear CG methods.
Phase 1: noise candidates = pixels equal to 0 or 255; initial values from a 3x3 median filter.
Phase 2: minimize f(u) = sum_{p in N} [ sum_{q in V_p \\ N} phi(u_p - y_q) + 1/2 sum_{q in V_p cap N} phi(u_p - u_q) ],
phi(t) = sqrt(t^2 + alpha), alpha = 100, V_p = 4-neighbourhood, over the values u at the candidate pixels."""
import numpy as np
from scipy.ndimage import median_filter

ALPHA = 100.0
def phi(t):  return np.sqrt(t * t + ALPHA)
def dphi(t): return t / np.sqrt(t * t + ALPHA)

SHIFTS = [(-1, 0), (1, 0), (0, -1), (0, 1)]

def neighbour(A, di, dj, fill=0.0):
    """B[i,j] = A[i+di, j+dj] (fill outside the image); also returns the validity mask."""
    H, W = A.shape
    B = np.full_like(A, fill, dtype=float); V = np.zeros((H, W), bool)
    i0, i1 = max(0, -di), H - max(0, di); j0, j1 = max(0, -dj), W - max(0, dj)
    B[i0:i1, j0:j1] = A[i0 + di:i1 + di, j0 + dj:j1 + dj]; V[i0:i1, j0:j1] = True
    return B, V

class Denoise:
    def __init__(self, clean, noisy, name):
        self.clean = clean.astype(float); self.y = noisy.astype(float); self.name = name
        self.N = (noisy == 0) | (noisy == 255)
        self.idx = np.nonzero(self.N.ravel())[0]
        self.u0 = median_filter(self.y, size=3).ravel()[self.idx].astype(float)
        self.nbr = []
        for di, dj in SHIFTS:
            Nq, V = neighbour(self.N.astype(float), di, dj); self.nbr.append((di, dj, V, Nq > 0.5))
    def image(self, u):
        U = self.y.ravel().copy(); U[self.idx] = u; return U.reshape(self.y.shape)
    def f(self, u):
        U = self.image(u); tot = 0.0
        for di, dj, V, Nq in self.nbr:
            Uq, _ = neighbour(U, di, dj); D = U - Uq
            w = self.N & V
            tot += np.sum(phi(D[w & ~Nq])) + 0.5 * np.sum(phi(D[w & Nq]))
        return float(tot)
    def g(self, u):
        U = self.image(u); G = np.zeros_like(U)
        for di, dj, V, Nq in self.nbr:
            Uq, _ = neighbour(U, di, dj); G += np.where(self.N & V, dphi(U - Uq), 0.0)
        return G.ravel()[self.idx]
    def x0(self, n=None): return self.u0.copy()
    def psnr(self, u):
        mse = np.mean((np.clip(self.image(u), 0, 255) - self.clean) ** 2); return 10 * np.log10(255.0 ** 2 / mse)

def add_salt_pepper(img, level, seed):
    rng = np.random.default_rng(seed); out = img.copy(); r = rng.random(img.shape)
    out[r < level / 2] = 0; out[(r >= level / 2) & (r < level)] = 255
    return out

