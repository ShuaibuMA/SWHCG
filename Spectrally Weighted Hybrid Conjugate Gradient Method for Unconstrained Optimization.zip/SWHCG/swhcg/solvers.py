"""Nonlinear CG solvers under the modified strong Wolfe line search of
Ibrahim, Kumam, Kamandi & Abubakar (OMS 2022), with Powell restarts.

Methods: SWHCG (proposed), HYB (base paper), LS, HZ, DY, PRP+, KMD,
plus ablation variants (fixed theta).
"""
import time
import numpy as np


class Counter:
    def __init__(self, f, g):
        self._f, self._g = f, g
        self.nf = 0
        self.ng = 0

    def f(self, x):
        self.nf += 1
        return self._f(x)

    def g(self, x):
        self.ng += 1
        return self._g(x)


def modified_strong_wolfe(cnt, x, f0, g0d, d, alpha0,
                          sigma1=1e-3, sigma2=1e-6, zeta=0.33,
                          alpha_max=1e10, max_ls=40):
    """Line search for the modified strong Wolfe conditions
        f(x+a d) <= f0 + sigma1 a g0d - sigma2 a^2 ||d||^2
        |g(x+a d)' d| <= -zeta g0d
    Returns (alpha, f_new, g_new) or (None, None, None) on failure.
    Bracketing + zoom (Nocedal & Wright Alg. 3.5/3.6 adapted to the
    modified sufficient decrease function)."""
    dd = float(d @ d)

    def phi(a):
        return cnt.f(x + a * d)

    def dphi(a, cache):
        gnew = cnt.g(x + a * d)
        cache["g"] = gnew
        return float(gnew @ d)

    def suff(a, fa):
        return fa <= f0 + sigma1 * a * g0d - sigma2 * a * a * dd

    a_prev, f_prev = 0.0, f0
    a = max(min(alpha0, alpha_max), 1e-16)
    cache = {}
    for i in range(max_ls):
        fa = phi(a)
        if (not suff(a, fa)) or (i > 0 and fa >= f_prev):
            return _zoom(cnt, x, f0, g0d, d, dd, a_prev, f_prev, a, fa,
                         sigma1, sigma2, zeta)
        da = dphi(a, cache)
        if abs(da) <= -zeta * g0d:
            return a, fa, cache["g"]
        if da >= 0.0:
            return _zoom(cnt, x, f0, g0d, d, dd, a, fa, a_prev, f_prev,
                         sigma1, sigma2, zeta)
        a_prev, f_prev = a, fa
        a = min(2.0 * a, alpha_max)
        if a >= alpha_max:
            return None, None, None
    return None, None, None


def _zoom(cnt, x, f0, g0d, d, dd, alo, flo, ahi, fhi,
          sigma1, sigma2, zeta, max_zoom=40):
    def phi(a):
        return cnt.f(x + a * d)

    def suff(a, fa):
        return fa <= f0 + sigma1 * a * g0d - sigma2 * a * a * dd

    for _ in range(max_zoom):
        a = 0.5 * (alo + ahi)
        if abs(ahi - alo) < 1e-16 * max(1.0, abs(alo)):
            break
        fa = phi(a)
        if (not suff(a, fa)) or fa >= flo:
            ahi, fhi = a, fa
        else:
            gnew = cnt.g(x + a * d)
            da = float(gnew @ d)
            if abs(da) <= -zeta * g0d:
                return a, fa, gnew
            if da * (ahi - alo) >= 0.0:
                ahi, fhi = alo, flo
            alo, flo = a, fa
    return None, None, None


def run_cg(problem, n, method, tol=1e-6, max_iter=5000, max_nf=200000,
           tau=1e-3, p_exp=2.0, theta_max=0.1, restart=True, fixed_theta=None,
           gamma_r=None, powell_c=0.2, x0=None, return_x=False):
    """method in {SWHCG, HYB, LS, HZ, DY, PRP+, KMD}.
    powell_c: Powell restart constant (default 0.2, as in the paper).
    x0: optional starting point overriding problem.x0(n) (multi-start runs)."""
    cnt = Counter(problem.f, problem.g)
    x = (problem.x0(n) if x0 is None else x0).astype(float)
    stats = {"guard": 0, "fallback": 0, "cg_iters": 0, "reset": 0}
    t0 = time.perf_counter()
    fx = cnt.f(x)
    g = cnt.g(x)
    gnorm = float(np.linalg.norm(g, np.inf))
    d = -g
    s_prev = y_prev = None
    k = 0
    n_restarts = 0
    theta_log = []
    while gnorm > tol:
        if k >= max_iter or cnt.nf >= max_nf or not np.isfinite(fx):
            stats['x'] = x.copy() if return_x else None

            return _result(False, k, cnt, t0, fx, gnorm, n_restarts, theta_log, stats)
        gd = float(g @ d)
        if gd >= 0.0:                      # safeguard: restart on ascent
            stats["reset"] += 1
            d = -g
            gd = float(g @ d)
            n_restarts += 1
        # initial step: BB1 if available, else 1/||g0||
        if s_prev is None:
            a0 = 1.0 / max(gnorm, 1e-16)
        else:
            sy = float(s_prev @ y_prev)
            a0 = float(s_prev @ s_prev) / sy if sy > 1e-8 else 1.0
            a0 = min(max(a0, 1e-16), 1e10)
        alpha, fnew, gnew = modified_strong_wolfe(cnt, x, fx, gd, d, a0)
        if alpha is None:
            stats["fallback"] += 1
            alpha, fnew, gnew = _armijo_backtrack(cnt, x, fx, gd, d, a0)
            if alpha is None:
                stats['x'] = x.copy() if return_x else None

                return _result(False, k, cnt, t0, fx, gnorm,
                               n_restarts, theta_log, stats)
        xnew = x + alpha * d
        s = alpha * d
        y = gnew - g
        gnew_norm = float(np.linalg.norm(gnew, np.inf))

        # Powell restart criterion (SWHCG: suppressed when the fresh
        # secant pair certifies near-uniform curvature, gamma >= gamma_r)
        powell = abs(float(gnew @ g)) >= powell_c * float(gnew @ gnew)
        if powell and method == "SWHCG" and gamma_r is not None:
            sy = float(s @ y); ss = float(s @ s); yy = float(y @ y)
            gam = sy * sy / (ss * yy) if sy > 0 and ss > 0 and yy > 0 else 0.0
            if gam >= gamma_r:
                powell = False
        if restart and powell:
            dnew = -gnew
            n_restarts += 1
        else:
            stats["cg_iters"] += 1
            dnew = _direction(method, g, gnew, d, s, y, tau, p_exp, theta_max,
                              fixed_theta, theta_log, stats)
        x, fx, g, gnorm, d = xnew, fnew, gnew, gnew_norm, dnew
        s_prev, y_prev = s, y
        k += 1
    stats['x'] = x.copy() if return_x else None

    return _result(True, k, cnt, t0, fx, gnorm, n_restarts, theta_log, stats)


def _armijo_backtrack(cnt, x, f0, g0d, d, alpha0,
                      sigma1=1e-3, sigma2=1e-6, max_bt=50):
    dd = float(d @ d)
    a = max(min(alpha0, 1.0), 1e-16)
    for _ in range(max_bt):
        fa = cnt.f(x + a * d)
        if np.isfinite(fa) and fa <= f0 + sigma1 * a * g0d - sigma2 * a * a * dd:
            return a, fa, cnt.g(x + a * d)
        a *= 0.5
    return None, None, None


def _direction(method, g, gnew, d, s, y, tau, p_exp, theta_max, fixed_theta, theta_log,
               stats=None):
    gd = float(g @ d)
    yd = float(y @ d)
    dn = float(np.linalg.norm(d))
    gn1 = float(np.linalg.norm(gnew))
    beta_ls = float(y @ gnew) / (-gd) if abs(gd) > 1e-300 else 0.0
    beta_kmd = tau * gn1 / dn if dn > 1e-300 else 0.0

    if method == "LS":
        beta = beta_ls
    elif method == "KMD":
        beta = beta_kmd
    elif method == "DY":
        beta = gn1 ** 2 / yd if abs(yd) > 1e-300 else 0.0
    elif method == "PRP+":
        beta = max(float(y @ gnew) / float(g @ g), 0.0)
    elif method == "HZ":
        if abs(yd) > 1e-300:
            beta = float((y - 2.0 * (float(y @ y) / yd) * d) @ gnew) / yd
        else:
            beta = 0.0
    elif method == "HYB":                 # base paper theta^(2), t = 1
        num = dn * (float(y @ gnew) * float(d @ gnew)
                    - float(s @ gnew) * float(d @ g))
        den = yd * (float(y @ gnew) * dn + tau * float(d @ g) * gn1)
        th = num / den if abs(den) > 1e-300 else 0.0
        th = min(max(th, 0.0), 1.0)
        theta_log.append(th)
        beta = (1.0 - th) * beta_ls + th * beta_kmd
    elif method.startswith("SWHCG"):      # proposed spectral weight family
        sy = float(s @ y)
        ss = float(s @ s)
        yy = float(y @ y)
        if sy > 0 and ss > 0 and yy > 0:
            gamma = sy * sy / (ss * yy)
        else:
            gamma = 0.0
            if stats is not None:
                stats["guard"] += 1
        gamma = min(gamma, 1.0)
        num = dn * (float(y @ gnew) * float(d @ gnew)
                    - float(s @ gnew) * float(d @ g))
        den = yd * (float(y @ gnew) * dn + tau * float(d @ g) * gn1)
        th2 = num / den if abs(den) > 1e-300 else 0.0
        th2 = min(max(th2, 0.0), 1.0)
        if fixed_theta is not None:
            th = fixed_theta
        elif method == "SWHCG-A":
            th = th2 * (1.0 - gamma)
        elif method == "SWHCG-B":
            th = th2 * (1.0 - gamma) ** p_exp
        elif method == "SWHCG-C":
            th = min(th2, 1.0 - gamma)
        else:  # SWHCG: pure spectral weight
            th = theta_max * (1.0 - gamma) ** p_exp
        theta_log.append(th)
        beta = (1.0 - th) * beta_ls + th * beta_kmd
    else:
        raise ValueError(method)
    return -gnew + beta * d


def _result(conv, k, cnt, t0, fx, gnorm, n_restarts, theta_log, stats=None):
    stats = stats or {}
    return dict(conv=bool(conv), iters=k, nf=cnt.nf, ng=cnt.ng,
                time=time.perf_counter() - t0, f=float(fx),
                gnorm=float(gnorm), restarts=n_restarts,
                theta_mean=float(np.mean(theta_log)) if theta_log else None,
                guard=stats.get("guard", 0), fallback=stats.get("fallback", 0),
                cg_iters=stats.get("cg_iters", 0), reset=stats.get("reset", 0),
                **({"x": stats["x"]} if stats.get("x") is not None else {}))


if __name__ == "__main__":
    from problems import PROBLEMS
    for m in ["SWHCG", "HYB", "LS", "HZ", "DY", "PRP+", "KMD"]:
        r = run_cg(PROBLEMS[0], 1000, m)
        print(m, r)
