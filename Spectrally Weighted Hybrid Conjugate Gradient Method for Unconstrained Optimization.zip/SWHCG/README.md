# SWHCG — Spectrally Weighted Hybrid Conjugate Gradient method

Code, test problems and run-level results for

> M. S. Audu, H. Choi, M. U. Rehman, *Spectrally Weighted Hybrid Conjugate Gradient Method for Unconstrained Optimization*, AIMS Mathematics (under revision, manuscript Math-32238).

The method mixes the Liu–Storey (LS) and Kamandi–Amini (KMD) parameters,
β_k = (1 − θ_k) β_k^LS + θ_k β_k^KMD, with the weight θ_k = θ̄ (1 − γ_k)^p and
γ_k = (s_kᵀy_k)² / (‖s_k‖² ‖y_k‖²), the squared cosine between the step and the gradient change.
The proposed method is labelled **`SWHCG`** in the code and in all result files; every other label is a comparison method.

## Layout

| Path | Contents |
|---|---|
| `swhcg/problems.py` | The 35 test problems (Andrei collection / CUTEst analogues): `f`, analytic gradient, standard starting point |
| `swhcg/solvers.py` | `run_cg(problem, n, method, ...)`: the common CG frame (modified strong Wolfe line search, Powell restart, Armijo fallback, descent reset) and the β formulas `SWHCG`, `HYB`, `LS`, `HZ`, `DY`, `PRP+`, `KMD` |
| `swhcg/imgrest.py` | Two-phase salt-and-pepper denoising objective (edge-preserving functional, φ(t) = √(t² + 100)) |
| `experiments/` | One script per experiment in the paper (below) |
| `results/` | The JSON files behind every table and figure, one record per run |
| `notebooks/SWHCG_experiments_colab.ipynb` | The Colab notebook that produced the results |

## Installation

```bash
python -m venv .venv && source .venv/bin/activate      # Python 3.13
pip install -r requirements.txt
python experiments/00_check_gradients.py                 # finite-difference check of every gradient
```

## Experiments

Every script writes to `results_new/` (so the shipped `results/` stay untouched); use `--out` to change this.

| Script | Paper item | Output | Approx. time (Colab CPU) |
|---|---|---|---|
| `00_check_gradients.py` | gradient verification | — | seconds |
| `01_main_campaign.py [--check]` | main campaign, Tables 2–5 and 15 | `results_final.json` | 30–60 min |
| `02_sensitivity_ablation.py` | parameter grid and ablations (n = 1000), Tables 6–7 | `results_sens_abl.json` | 1–2 h |
| `03_multistart.py --n 1000` / `--n 5000` | ten-start campaigns, Tables 9–10 | `results_F10_multistart.json`, `results_R3_multistart_n5000.json` | 2–4 h / several hours (resumable) |
| `04_large_n.py [--skip-unsolved]` | n = 10⁴ and 10⁵, Table 11 and Table 16 | `results_R3_largeN.json` | about 4 h |
| `05_image_restoration.py` | salt-and-pepper denoising, Table 13 | `results_R2_imagerestoration.json` | about 20 min |
| `06_quadratic.py` | convex quadratics, κ = 10 … 10⁴, Table 12 | `results_R1_quadratic.json` | 1 min |
| `07_profiles.py` | Dolan–Moré profiles, Figure 1 | `profile_*.pdf` | seconds |
| `09_denoising_figure.py` | denoised images, Figure 3 | `denoising_swhcg.pdf` | about 10 min |
| `08_summarise_revision.py` | statistics for the revision (Holm–Wilcoxon, ranks, image totals) | printed | seconds |

Common settings: stopping test ‖g‖∞ ≤ 10⁻⁶, at most 5000 iterations and 2 × 10⁵ function evaluations;
τ = 10⁻² for SWHCG and 10⁻³ for the other methods; θ̄ = 0.1, p = 2.
Multi-start campaigns perturb the standard point by 10% (`perturbed_start` in `experiments/_common.py`, seeds 0–9);
the per-problem median over ten starts counts failures as +∞, so it is finite only when at least six starts converge.

## Result files

Each `results_*.json` of a campaign maps `"problem|n"` to `{method: record}`, where a record holds
`conv, iters, nf, ng, time, f, gnorm, restarts, theta_mean, guard, fallback, cg_iters, reset`.
Multi-start files map `method → problem → [nf per start]` with `null` for a failed start.
`results_R3_largeN.json` was regenerated with `04_large_n.py --skip-unsolved` under `reproduce_env.sh`
after the original Colab file was lost; its totals (solved, it, nf, ng for all seven methods at both
dimensions) match those printed by the Colab run exactly. It omits POWER, FLETCHCR, Generalized Rosenbrock
and DIXON3DQ, which no method solves at either dimension.
`figures/` holds the figures of the paper.

## Computing environment and reproducibility

All reported runs used Google Colab (CPU runtime, Linux x86_64, Python 3.13, NumPy 2.1.3; the recorded
session had an Intel Xeon @ 2.20 GHz with 2 vCPUs and 12 GB RAM). Colab may assign different hardware
per session, so CPU times are indicative only; iteration and evaluation counts are the primary measures.

Pin NumPy 2.1.3. Rerunning `01_main_campaign.py --check` on Colab reproduced `results_final.json` exactly.

The Colab processors used AVX2 but not AVX-512. On an AVX-512 processor NumPy and OpenBLAS take
different vectorised code paths, whose sums round differently in the last bit; CG trajectories amplify
such differences, so individual counts change (the aggregate conclusions do not). To reproduce the
shipped counts bit for bit on any x86-64 machine, restrict both libraries to the AVX2 paths first:

```bash
source reproduce_env.sh      # sets NPY_DISABLE_CPU_FEATURES, OPENBLAS_CORETYPE=Haswell, OPENBLAS_NUM_THREADS=2
python experiments/01_main_campaign.py --check    # expect: mismatches ... 0
```

OpenBLAS also splits long inner products (n ≈ 10⁵) across threads, and the split changes the rounding.
`reproduce_env.sh` therefore fixes two threads, as on the Colab runtime. Run the large-n and image scripts as
a single process on an otherwise idle machine: when two runs compete for the same cores, the counts at
n = 10⁵ change.

This was verified on an AVX-512 Intel Xeon (Python 3.13.18, NumPy 2.1.3): all 490 runs of the main
campaign (70 instances × 7 methods), all quadratic-study runs, all large-n runs and all 84 image-restoration runs
matched the Colab results exactly.

Implementation note: for the `SWHCG` method, `_direction` in `swhcg/solvers.py` also evaluates the
quasi-Newton weight of HYB, which is used only by experimental variants (`SWHCG-A/B/C`). It does not
affect any count, but it adds a few inner products to SWHCG's CPU time. It is kept so that the shipped
timings remain reproducible.

## Licence

MIT (see `LICENSE`).
