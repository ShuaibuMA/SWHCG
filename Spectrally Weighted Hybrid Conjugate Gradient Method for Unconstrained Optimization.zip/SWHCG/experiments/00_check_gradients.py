"""Finite-difference check of every analytic gradient (test set and image-restoration objective)."""
import numpy as np
from _common import PROBLEMS

rng = np.random.default_rng(0); worst = 0.0
for p in PROBLEMS:
    n = 12
    x = p.x0(n).astype(float) + 0.05 * rng.standard_normal(n)
    g = p.g(x); h = 1e-6; gfd = np.zeros(n)
    for i in range(n):
        e = np.zeros(n); e[i] = h
        gfd[i] = (p.f(x + e) - p.f(x - e)) / (2 * h)
    rel = np.linalg.norm(g - gfd) / max(np.linalg.norm(gfd), 1e-12); worst = max(worst, rel)
    print(f"{p.name:34s} rel.err = {rel:.2e}  {'ok' if rel < 1e-6 else 'CHECK'}")
try:
    from swhcg.imgrest import Denoise, add_salt_pepper
    img = np.random.default_rng(1).integers(1, 255, (24, 24)).astype(float)
    D = Denoise(img, add_salt_pepper(img, 0.5, 3), "rand")
    u = D.u0 + rng.standard_normal(D.u0.size); g = D.g(u); h = 1e-4
    gfd = np.array([(D.f(u + h * e) - D.f(u - h * e)) / (2 * h) for e in np.eye(u.size)])
    rel = np.linalg.norm(g - gfd) / np.linalg.norm(gfd); worst = max(worst, rel)
    print(f"{'image-restoration objective':34s} rel.err = {rel:.2e}")
except ImportError as exc:
    print("image-restoration check skipped:", exc)
print(f"\nworst relative error: {worst:.2e}")
assert worst < 1e-5, "gradient check failed"
