"""Parameter grid (theta_bar x p, tau sweep) and ablations at n = 1000 (results_sens_abl.json)."""
import time
from _common import PROBLEMS, BUDGET, run_cg, out_path, dump, base_parser

args = base_parser(__doc__).parse_args()
sa = {}

def sweep(tag, method="SWHCG", **kw):
    t0 = time.time()
    sa[tag] = {p.name: run_cg(p, 1000, method, **BUDGET, **kw) for p in PROBLEMS}
    print(f"{tag:22s} solved {sum(v['conv'] for v in sa[tag].values())}/35  [{time.time()-t0:.0f}s]")

for tm in [0.05, 0.1, 0.2, 0.4]:
    for pe in [1.0, 2.0, 4.0]:
        sweep(f"sens_tm{tm}_p{pe}", tau=1e-2, theta_max=tm, p_exp=pe)
for tau in [1e-4, 1e-3, 1e-2, 1e-1]:
    sweep(f"sens_tau{tau}", tau=tau, theta_max=0.1, p_exp=2.0)
sweep("abl_theta0", tau=1e-2, fixed_theta=0.0)
sweep("abl_theta005", tau=1e-2, fixed_theta=0.05)
sweep("abl_theta1", tau=1e-2, fixed_theta=1.0)
sweep("abl_norestart", tau=1e-2, theta_max=0.1, p_exp=2.0, restart=False)
sweep("abl_hyb_tau01", method="HYB", tau=1e-2)
dump(sa, out_path(args, "results_sens_abl.json"))
