"""Summaries used in the revision: quadratic study, n = 5000 multi-start (Holm-Wilcoxon, per-seed ranks), image restoration."""
import json, math, numpy as np, sys
from scipy.stats import wilcoxon
import os; U=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),'results')+'/'
M=['SWHCG','HYB','LS','HZ','DY','PRP+','KMD']
print("==== QUADRATIC ====")
q=json.load(open(U+'results_R1_quadratic.json'))
for k,v in q.items():
    kap=float(k); b=0.1*((kap-1)/(kap+1))**4
    s,t0,tb=map(np.array,(v['SWHCG'],v['theta0'],v['theta_bar']))
    def w(a,c):
        try: return wilcoxon(a,c).pvalue
        except: return float('nan')
    print(f"k={kap:g} med S={np.median(s)} th0={np.median(t0)} thb={np.median(tb)} mean S={s.mean():.1f} th0={t0.mean():.1f} thb={tb.mean():.1f} p(S vs th0)={w(s,t0):.3f} p(S vs thb)={w(s,tb):.3f} theta_mean={np.mean(v['theta_mean']):.4f} bound={b:.4f}")
print("==== MULTISTART n=5000 ====")
d=json.load(open(U+'results_R3_multistart_n5000.json'))
probs=list(d['SWHCG'])
def med(l):
    a=sorted([x if x is not None else math.inf for x in l]); return (a[4]+a[5])/2
nruns={m:sum(x is not None for p in probs for x in d[m][p]) for m in M}
tot=sum(len(d['SWHCG'][p]) for p in probs)
MED={m:{p:med(d[m][p]) for p in probs} for m in M}
print("problems",len(probs),"runs per method",tot)
solv_any=[p for p in probs if any(MED[m][p]<math.inf for m in M)]
common=[p for p in probs if all(MED[m][p]<math.inf for m in M)]
print("median-solvable by some",len(solv_any),"common",len(common))
for m in M:
    print(f"{m:6s} runs {nruns[m]}/{tot} median-solved {sum(MED[m][p]<math.inf for p in probs)} summed-median-nf(common) {sum(MED[m][p] for p in common):.0f}")
print("-- Wilcoxon SWHCG vs others (both finite)")
res=[]
for m in M[1:]:
    P=[p for p in probs if MED['SWHCG'][p]<math.inf and MED[m][p]<math.inf]
    a=np.array([MED['SWHCG'][p] for p in P]); b=np.array([MED[m][p] for p in P])
    r=np.exp(np.median(np.log(a/b)))
    W=sum(a<b*0.95);L=sum(a>b*1.05);T=len(P)-W-L
    try: pv=wilcoxon(a,b).pvalue
    except: pv=1.0
    res.append([m,len(P),r,a.sum()/b.sum(),W,L,T,pv])
o=sorted(range(len(res)),key=lambda i:res[i][-1]); k=len(res); prev=0
for j,i in enumerate(o):
    h=min(1,max(prev,(k-j)*res[i][-1])); prev=h; res[i].append(h)
for r in res: print(f"vs {r[0]:5s} n={r[1]} geo-ratio={r[2]:.3f} sum-ratio={r[3]:.3f} W-L-T={r[4]}-{r[5]}-{r[6]} p={r[7]:.4f} holm={r[8]:.4f}")
print("-- per-seed rank of SWHCG (sum nf on instances all 7 solved in that seed)")
ranks=[]
for s in range(10):
    P=[p for p in probs if all(d[m][p][s] is not None for m in M)]
    tots={m:sum(d[m][p][s] for p in P) for m in M}
    rk=sorted(M,key=lambda m:tots[m]).index('SWHCG')+1; ranks.append(rk)
    solved={m:sum(d[m][p][s] is not None for p in probs) for m in M}
    print(s,len(P),rk,{m:tots[m] for m in M}, 'solved',solved)
print("ranks",ranks)
print("==== IMAGE ====")
r=json.load(open(U+'results_R2_imagerestoration.json'))
agg={m:dict(it=0,nf=0,ng=0,t=0.0,ps=[],conv=0) for m in M}
for c,v in r.items():
    line=f"{c:14s} n={v['n']:6d} med={v['psnr_median']:.2f} "
    pss=[v[m]['psnr'] for m in M]
    for m in M:
        a=agg[m];x=v[m];a['it']+=x['iters'];a['nf']+=x['nf'];a['ng']+=x['ng'];a['t']+=x['time'];a['ps'].append(x['psnr']);a['conv']+=x['conv']
    line+=" ".join(f"{m}:{v[m]['iters']}/{v[m]['nf']}/{v[m]['time']:.0f}" for m in M)+f" spread={max(pss)-min(pss):.3f} restartfrac S={v['SWHCG']['restarts']/max(1,v['SWHCG']['iters']):.2f}"
    print(line)
for m in M:
    a=agg[m];print(f"{m:6s} conv {a['conv']}/12 it {a['it']} nf {a['nf']} ng {a['ng']} time {a['t']:.0f} meanPSNR {np.mean(a['ps']):.3f}")
for key in ['nf','time','iters']:
    best={m:0 for m in M}
    for c,v in r.items(): best[min(M,key=lambda m:v[m][key])]+=1
    print('best',key,best)
for m in M[1:]:
    W=L=0
    for c,v in r.items():
        a,b=v['SWHCG']['nf'],v[m]['nf']
        W+=a<0.95*b;L+=a>1.05*b
    print(f"nf W-L-T vs {m}: {W}-{L}-{12-W-L}")
