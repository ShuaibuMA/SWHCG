"""Salt-and-pepper denoising (two-phase edge-preserving model) on four scikit-image test images
at 30/50/70% noise (results_R2_imagerestoration.json). Needs scikit-image."""
import numpy as np
import skimage.data as skd
from skimage.color import rgb2gray
from _common import METHODS, TAU, run_cg, out_path, dump, base_parser
from swhcg.imgrest import Denoise, add_salt_pepper

args = base_parser(__doc__).parse_args()
IMAGES = {"camera": skd.camera().astype(float),
          "astronaut": (rgb2gray(skd.astronaut()) * 255).round(),
          "moon": skd.moon().astype(float),
          "coffee": (rgb2gray(skd.coffee()) * 255).round()[:400, :512]}
res = {}
for iname, img in IMAGES.items():
    for lev in [0.3, 0.5, 0.7]:
        P = Denoise(img, add_salt_pepper(img, lev, seed=7), f"{iname}-{int(lev*100)}")
        n = P.u0.size; tol = 1e-4 * max(1.0, np.linalg.norm(P.g(P.x0()), np.inf))
        row = {"n": int(n), "psnr_median": P.psnr(P.x0())}
        for m in METHODS:
            r = run_cg(P, n, m, tol=tol, max_iter=5000, max_nf=200000, tau=TAU[m], return_x=True)
            x = r.pop("x"); r["psnr"] = P.psnr(x); row[m] = r
        res[P.name] = row
        print(f"{P.name:14s} n={n:6d} median-filter PSNR={row['psnr_median']:.2f}  "
              + "  ".join(f"{m}:{row[m]['iters']}it/{row[m]['psnr']:.2f}dB" for m in METHODS))
dump(res, out_path(args, "results_R2_imagerestoration.json"))
