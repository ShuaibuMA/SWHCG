"""Ten perturbed starts per problem (n = 1000 -> results_F10_multistart.json, n = 5000 -> results_R3_multistart_n5000.json).
Resumable: the output is saved after every problem and finished problems are skipped on restart."""
import json, os, time
import numpy as np
from _common import PROBLEMS, METHODS, TAU, BUDGET, run_cg, perturbed_start, median10, holm_wilcoxon, out_path, dump, base_parser

ap = base_parser(__doc__)
ap.add_argument("--n", type=int, default=5000)
ap.add_argument("--seeds", type=int, default=10)
args = ap.parse_args()
path = out_path(args, "results_F10_multistart.json" if args.n == 1000 else f"results_R3_multistart_n{args.n}.json")
ms = {m: {} for m in METHODS}
if os.path.exists(path):
    ms = json.load(open(path)); print(f"resuming: {len(ms['SWHCG'])} problems done")
t0 = time.time()
for p in PROBLEMS:
    if p.name in ms["SWHCG"]:
        continue
    for sd in range(args.seeds):
        x0 = perturbed_start(p, args.n, sd)
        for m in METHODS:
            r = run_cg(p, args.n, m, tau=TAU[m], x0=x0, **BUDGET)
            ms[m].setdefault(p.name, []).append(r["nf"] if r["conv"] else None)
    dump(ms, path); print(f"[{time.time()-t0:7.0f}s] {p.name}")

names = list(ms["SWHCG"])
med = {m: {k: median10(ms[m][k]) for k in names} for m in METHODS}
common = [k for k in names if all(np.isfinite(med[m][k]) for m in METHODS)]
print(f"\nn={args.n}, {args.seeds} starts, {len(names)} problems")
for m in METHODS:
    print(f"  {m:6s} runs solved={sum(v is not None for k in names for v in ms[m][k]):3d}/{args.seeds*len(names)}"
          f"  median solved={sum(np.isfinite(med[m][k]) for k in names):2d}"
          f"  sum of medians ({len(common)} common)={sum(med[m][k] for k in common):.0f}")
holm_wilcoxon(med)
