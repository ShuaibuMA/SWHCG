"""Dolan-More performance profiles (nf, iterations, gradient evaluations, CPU time) from a results_final.json."""
import json, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from _common import METHODS, RESULTS, out_path, base_parser

ap = base_parser(__doc__)
ap.add_argument("--results", default=os.path.join(RESULTS, "results_final.json"))
args = ap.parse_args()
res = json.load(open(args.results))
solvable = [k for k in res if any(res[k][m]["conv"] for m in METHODS)]
for metric in ["nf", "iters", "ng", "time"]:
    fig, ax = plt.subplots(figsize=(4.9, 3.7)); ts = np.linspace(0, 10, 400)
    for m in METHODS:
        r = []
        for k in solvable:
            best = min(res[k][mm][metric] for mm in METHODS if res[k][mm]["conv"])
            r.append(np.log2(max(res[k][m][metric] / best, 1.0)) if res[k][m]["conv"] else np.inf)
        r = np.array(r)
        ax.plot(ts, [(r <= t).sum() / len(solvable) for t in ts], lw=1.5, label=m)
    ax.set_xlabel(r"$\log_2 r$"); ax.set_ylabel(r"$\rho_s(r)$"); ax.set_ylim(0, 1.02)
    ax.grid(alpha=0.3); ax.legend(fontsize=8, loc="lower right"); fig.tight_layout()
    fig.savefig(out_path(args, f"profile_{metric}.pdf")); plt.close(fig)
    print("saved", out_path(args, f"profile_{metric}.pdf"))
