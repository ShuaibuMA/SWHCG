"""Main campaign: 35 problems x n in {1000, 5000} x 7 methods (results_final.json), plus summary statistics.
--check compares the new run with the shipped results/results_final.json (expect 0 mismatches)."""
import json, os, time
import numpy as np
from _common import PROBLEMS, METHODS, TAU, BUDGET, RESULTS, run_cg, out_path, dump, base_parser

ap = base_parser(__doc__)
ap.add_argument("--dims", type=int, nargs="+", default=[1000, 5000])
ap.add_argument("--check", action="store_true")
args = ap.parse_args()

res = {}; t0 = time.time()
for n in args.dims:
    for p in PROBLEMS:
        key = f"{p.name}|{n}"
        res[key] = {m: run_cg(p, n, m, tau=TAU[m], p_exp=2.0, theta_max=0.1, **BUDGET) for m in METHODS}
        print(f"[{time.time()-t0:7.1f}s] {key:44s} " + " ".join(f"{m}:{'Y' if res[key][m]['conv'] else 'n'}" for m in METHODS))
dump(res, out_path(args, "results_final.json"))

solvable = [k for k in res if any(res[k][m]["conv"] for m in METHODS)]
common = [k for k in res if all(res[k][m]["conv"] for m in METHODS)]
print(f"\ninstances {len(res)}, solvable {len(solvable)}, solved by all {len(common)}")
for m in METHODS:
    print(f"  {m:6s} solved {sum(res[k][m]['conv'] for k in solvable):2d}  "
          + "  ".join(f"{c}={sum(res[k][m][c] for k in common)}" for c in ("iters", "nf", "ng")))
if args.check:
    base = json.load(open(os.path.join(RESULTS, "results_final.json")))
    bad = [(k, m) for k in res for m in METHODS if k in base and
           tuple(res[k][m][c] for c in ("iters", "nf", "ng", "conv")) != tuple(base[k][m][c] for c in ("iters", "nf", "ng", "conv"))]
    print("\nmismatches against results/results_final.json:", len(bad), bad[:10])
