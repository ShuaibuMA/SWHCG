"""Shared settings for the experiment scripts (same values as the paper and notebook)."""
import json, math, os, sys
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from swhcg.problems import PROBLEMS, P  # noqa: E402
from swhcg.solvers import run_cg        # noqa: E402

METHODS = ["SWHCG", "HYB", "LS", "HZ", "DY", "PRP+", "KMD"]   # SWHCG = the proposed method
TAU = {m: 1e-3 for m in METHODS}
TAU["SWHCG"] = 1e-2
BUDGET = dict(tol=1e-6, max_iter=5000, max_nf=200000)
RESULTS = os.path.join(ROOT, "results")


def out_path(args, name):
    os.makedirs(args.out, exist_ok=True)
    return os.path.join(args.out, name)


def perturbed_start(p, n, seed):
    """Start used by every multi-start campaign: 10% relative perturbation of the standard point."""
    x_std = p.x0(n).astype(float)
    u = np.random.default_rng(1000 + seed).uniform(-1, 1, n)
    return np.where(x_std != 0, x_std * (1 + 0.1 * u), 0.1 * u)


def median10(vals):
    """Median over starts with failures (None/inf) counted as +inf.
    With 10 starts this is the mean of the 5th and 6th sorted values,
    so it is finite only when at least 6 starts converge."""
    a = sorted(math.inf if v is None else v for v in vals)
    m = len(a)
    return a[m // 2] if m % 2 else 0.5 * (a[m // 2 - 1] + a[m // 2])


def holm_wilcoxon(med, ref="SWHCG", methods=METHODS):
    """Paired Wilcoxon signed-rank test on per-problem medians (problems where both are finite), Holm-corrected."""
    from scipy.stats import wilcoxon
    rows = []
    for m in methods:
        if m == ref:
            continue
        ks = [k for k in med[ref] if np.isfinite(med[ref][k]) and np.isfinite(med[m][k])]
        a = np.array([med[ref][k] for k in ks]); b = np.array([med[m][k] for k in ks])
        p = wilcoxon(a, b).pvalue if np.any(a != b) else 1.0
        rows.append([m, len(ks), float(np.median(a / b)), p])
    order = sorted(range(len(rows)), key=lambda i: rows[i][3]); prev = 0.0
    for r, i in enumerate(order):
        prev = max(prev, min(1.0, (len(rows) - r) * rows[i][3])); rows[i].append(prev)
    for m, n_, ratio, p, ph in rows:
        print(f"  {ref} vs {m:5s} problems={n_:2d} median ratio={ratio:.3f} p={p:.4f} Holm p={ph:.4f}")
    return rows


def dump(obj, path):
    def clean(v):
        if isinstance(v, float) and not math.isfinite(v):
            return None
        if isinstance(v, dict):
            return {k: clean(x) for k, x in v.items()}
        if isinstance(v, list):
            return [clean(x) for x in v]
        return v
    with open(path, "w") as fh:
        json.dump(clean(obj), fh)
    print(f"saved {path}")


def base_parser(desc):
    import argparse
    ap = argparse.ArgumentParser(description=desc)
    ap.add_argument("--out", default=os.path.join(ROOT, "results_new"),
                    help="output folder (default: results_new/, so the shipped results/ are not overwritten)")
    return ap
