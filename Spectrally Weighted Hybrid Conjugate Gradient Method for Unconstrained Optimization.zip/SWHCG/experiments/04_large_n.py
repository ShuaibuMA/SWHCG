"""All 35 problems at n = 10^4 and 10^5 (results_R3_largeN.json). Slow: about 4 h on a Colab CPU.
Use --skip-unsolved to skip the four problems no method solves at n = 5000 (they only exhaust the budget)."""
import time
from _common import PROBLEMS, METHODS, TAU, BUDGET, run_cg, out_path, dump, base_parser

ap = base_parser(__doc__)
ap.add_argument("--dims", type=int, nargs="+", default=[10000, 100000])
ap.add_argument("--skip-unsolved", action="store_true")
args = ap.parse_args()
SKIP = {"POWER", "FLETCHCR", "Generalized Rosenbrock", "DIXON3DQ"} if args.skip_unsolved else set()
large = {}; t0 = time.time()
for n in args.dims:
    for p in PROBLEMS:
        if p.name in SKIP:
            continue
        key = f"{p.name}|{n}"
        large[key] = {m: run_cg(p, n, m, tau=TAU[m], **BUDGET) for m in METHODS}
        print(f"[{time.time()-t0:7.1f}s] {key:40s} " + " ".join(f"{m}:{'Y' if large[key][m]['conv'] else 'n'}" for m in METHODS))
        dump(large, out_path(args, "results_R3_largeN.json"))
for n in args.dims:
    ks = [k for k in large if k.endswith(f"|{n}")]
    solv = [k for k in ks if any(large[k][m]["conv"] for m in METHODS)]
    com = [k for k in solv if all(large[k][m]["conv"] for m in METHODS)]
    print(f"\nn={n}: solvable {len(solv)}, solved by all {len(com)}")
    for m in METHODS:
        print(f"  {m:6s} solved={sum(large[k][m]['conv'] for k in solv):2d}  "
              + "  ".join(f"{c}={sum(large[k][m][c] for k in com)}" for c in ("iters", "nf", "ng")))
