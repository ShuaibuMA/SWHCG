"""Figure for the image-restoration section: original, noisy and SWHCG-restored images at 30/50/70% noise,
with PSNR. Reruns SWHCG on the 12 cases of 05_image_restoration.py (about 10 min on a laptop CPU)."""
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import skimage.data as skd
from skimage.color import rgb2gray
from _common import run_cg, TAU, out_path, base_parser
from swhcg.imgrest import Denoise, add_salt_pepper

args = base_parser(__doc__).parse_args()
IMAGES = {"Cameraman": skd.camera().astype(float),
          "Astronaut": (rgb2gray(skd.astronaut()) * 255).round(),
          "Moon": skd.moon().astype(float),
          "Coffee": (rgb2gray(skd.coffee()) * 255).round()[:400, :512]}
psnr = lambda a, b: 10 * np.log10(255.0 ** 2 / np.mean((a - b) ** 2))
fig, ax = plt.subplots(4, 7, figsize=(7.2, 4.9), gridspec_kw=dict(wspace=0.04, hspace=0.18))
titles = ["Original"] + sum([[f"{l}% noise", f"SWHCG ({l}%)"] for l in (30, 50, 70)], [])
for i, (name, img) in enumerate(IMAGES.items()):
    panels = [(img, "")]
    for lev in (0.3, 0.5, 0.7):
        noisy = add_salt_pepper(img, lev, seed=7)
        P = Denoise(img, noisy, name)
        tol = 1e-4 * max(1.0, np.linalg.norm(P.g(P.x0()), np.inf))
        r = run_cg(P, P.u0.size, "SWHCG", tol=tol, max_iter=5000, max_nf=200000, tau=TAU["SWHCG"], return_x=True)
        rest = np.clip(P.image(r["x"]), 0, 255)
        print(f"{name}-{int(lev*100)}: it={r['iters']} nf={r['nf']} PSNR={psnr(rest, img):.2f} dB", flush=True)
        panels += [(noisy, f"{psnr(noisy, img):.2f} dB"), (rest, f"{psnr(rest, img):.2f} dB")]
    for j, (im, t) in enumerate(panels):
        a = ax[i, j]; a.imshow(im, cmap="gray", vmin=0, vmax=255, interpolation="nearest")
        a.set_xticks([]); a.set_yticks([])
        if t: a.set_xlabel(t, fontsize=6.5, labelpad=1.5)
        if i == 0: a.set_title(titles[j], fontsize=7, pad=3)
        if j == 0: a.set_ylabel(name, fontsize=7.5)
fig.savefig(out_path(args, "denoising_swhcg.pdf"), bbox_inches="tight", dpi=300)
print("saved", out_path(args, "denoising_swhcg.pdf"))
