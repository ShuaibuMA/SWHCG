"""Convex quadratics f = x'Ax/2, A = diag(logspace(0, log10 kappa, 1000)): adaptive weight vs theta = 0 (LS)
and theta = 0.1, ten random starts per kappa (results_R1_quadratic.json)."""
import numpy as np
from _common import P, run_cg, out_path, dump, base_parser

args = base_parser(__doc__).parse_args()
quad = {}
for kappa in [10, 1e2, 1e3, 1e4]:
    lam = np.logspace(0, np.log10(kappa), 1000)
    Q = P(f"quad-k{int(kappa)}", lambda x, l=lam: 0.5 * float(np.dot(l * x, x)), lambda x, l=lam: l * x, None)
    out = {"SWHCG": [], "theta0": [], "theta_bar": [], "theta_mean": []}
    it = lambda r: r["iters"] if r["conv"] else None
    for sd in range(10):
        x0 = np.random.default_rng(500 + sd).standard_normal(1000)
        tol = 1e-6 * max(1.0, np.linalg.norm(lam * x0, np.inf))
        r = run_cg(Q, 1000, "SWHCG", tol=tol, max_iter=5000, max_nf=200000, tau=1e-2, x0=x0)
        out["SWHCG"].append(it(r)); out["theta_mean"].append(r["theta_mean"] or 0.0)
        out["theta0"].append(it(run_cg(Q, 1000, "SWHCG", tol=tol, tau=1e-2, fixed_theta=0.0, x0=x0)))
        out["theta_bar"].append(it(run_cg(Q, 1000, "SWHCG", tol=tol, tau=1e-2, fixed_theta=0.1, x0=x0)))
    quad[str(kappa)] = out
    print(f"kappa={kappa:8.0f}  median iterations: SWHCG={np.median(out['SWHCG']):6.1f}  theta=0={np.median(out['theta0']):6.1f}"
          f"  theta=0.1={np.median(out['theta_bar']):6.1f}  mean theta_k={np.mean(out['theta_mean']):.4f}"
          f"  (bound {0.1*((kappa-1)/(kappa+1))**4:.4f})")
dump(quad, out_path(args, "results_R1_quadratic.json"))
