# n = 10^4 and 10^5 (experiments/04_large_n.py), totals as printed by the Colab run (13,758 s)

Thirty of the 35 problems are solved by at least one method at each n; 22 are solved by all seven methods.
Iteration, nf and ng totals are over those 22 common instances.

| Method | n=10^4 solved/30 | it | nf | ng | n=10^5 solved/30 | it | nf | ng |
|---|---|---|---|---|---|---|---|---|
| SWHCG | 29 | 1053 | 5470 | 2377 | 27 | 1737 | 24958 | 3480 |
| HYB | 29 | 1069 | 8976 | 2272 | 28 | 1630 | 28172 | 3050 |
| LS | 29 | 1121 | 6835 | 2506 | 25 | 1703 | 22923 | 3437 |
| HZ | 29 | 1377 | 7842 | 2994 | 24 | 2087 | 30759 | 4009 |
| DY | 29 | 975 | 5834 | 2132 | 28 | 1587 | 23634 | 3069 |
| PRP+ | 27 | 1090 | 6800 | 2402 | 27 | 1624 | 23304 | 3194 |
| KMD | 23 | 2670 | 17003 | 5889 | 24 | 2882 | 29672 | 6427 |
