# Restrict NumPy and OpenBLAS to the AVX2 code paths used on the Colab machines that produced results/.
# Usage:  source reproduce_env.sh
export NPY_DISABLE_CPU_FEATURES="AVX512F AVX512CD AVX512_SKX AVX512_CLX AVX512_CNL AVX512_ICL AVX512_SPR"
export OPENBLAS_CORETYPE=Haswell
export OPENBLAS_NUM_THREADS=2   # Colab CPU runtimes have 2 vCPUs; threaded BLAS sums depend on the thread count
